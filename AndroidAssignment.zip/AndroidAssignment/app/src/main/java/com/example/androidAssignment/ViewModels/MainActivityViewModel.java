package com.example.androidAssignment.ViewModels;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.androidAssignment.App;
import com.example.androidAssignment.Model.ListItem;
import com.example.androidAssignment.Repository;

import java.util.List;

public class MainActivityViewModel extends AndroidViewModel {

    private LiveData<List<ListItem>> listLiveData;

    public MainActivityViewModel(@NonNull Application application) {
        super(application);
        Repository mRepository = ((App) application).getRepository();
        listLiveData = mRepository.getList();
    }

    public LiveData<List<ListItem>> getListLiveData() {
        return listLiveData;
    }
}
