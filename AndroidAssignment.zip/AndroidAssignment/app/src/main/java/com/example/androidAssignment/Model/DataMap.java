package com.example.androidAssignment.Model;

import java.util.List;

public class DataMap {
    public List<String> options;
    public String currentInput;
}
