package com.example.androidAssignment.Model;

enum Type {
    PHOTO, SINGLE_CHOICE, COMMENT;
}

public class ListItem {
    public Type type;
    public String id;
    public String title;
    public DataMap dataMap;
}
