package com.example.androidAssignment.UI.ViewHolder;

public class PhotoViewHolder extends RecyclerView.ViewHolder {
}
