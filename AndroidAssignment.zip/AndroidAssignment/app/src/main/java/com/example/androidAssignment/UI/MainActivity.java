package com.example.androidAssignment.UI;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.androidAssignment.Model.ListItem;
import com.example.androidAssignment.R;
import com.example.androidAssignment.ViewModels.MainActivityViewModel;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    private MainActivityViewModel mainActivityViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mainActivityViewModel =
                new ViewModelProvider(this).get(
                        MainActivityViewModel.class);
        mainActivityViewModel.getListLiveData().observe(this,
                new Observer<List<ListItem>>() {
                    @Override
                    public void onChanged(List<ListItem> listItems) {
                        Log.d(TAG, String.valueOf(listItems));
//                        startActivity(new Intent(MainActivity.this,
//                                PhotoActivity.class));
                    }
                });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.action_bar_items, menu);
        return true;
    }

}
